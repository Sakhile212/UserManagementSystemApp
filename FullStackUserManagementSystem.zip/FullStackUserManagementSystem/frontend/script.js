let token = '';

const API_URL = 'http://localhost:5000/api/users';

// Register user
async function register() {
  const name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const age = document.getElementById('regAge').value;
  const password = document.getElementById('regPassword').value;

  const res = await fetch(`${API_URL}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, email, age, password })
  });
  const data = await res.json();
  alert(data.message || 'Registered successfully!');
}

// Login user
async function login() {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  const res = await fetch(`${API_URL}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();

  if (data.token) {
    token = data.token;
    document.getElementById('auth').style.display = 'none';
    document.getElementById('dashboard').style.display = 'block';
    fetchUsers();
  } else {
    alert(data.message);
  }
}

// Fetch all users
async function fetchUsers() {
  const res = await fetch(API_URL, { headers: { 'Authorization': `Bearer ${token}` } });
  const users = await res.json();

  const table = document.getElementById('userTable');
  table.innerHTML = `
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Age</th>
      <th>Actions</th>
    </tr>`;
  
  users.forEach(user => {
    const row = table.insertRow();
    row.innerHTML = `
      <td>${user.name}</td>
      <td>${user.email}</td>
      <td>${user.age}</td>
      <td>
        <button onclick="updateUser('${user._id}')">Edit</button>
        <button onclick="deleteUser('${user._id}')">Delete</button>
      </td>`;
  });
}

// Update user
async function updateUser(id) {
  const name = prompt('New Name:');
  const email = prompt('New Email:');
  const age = prompt('New Age:');

  await fetch(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ name, email, age })
  });
  fetchUsers();
}

// Delete user
async function deleteUser(id) {
  if (confirm('Are you sure?')) {
    await fetch(`${API_URL}/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    fetchUsers();
  }
}
